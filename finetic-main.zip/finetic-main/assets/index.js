import airbnb from "./airbnb.png";
import bill from "./bill.png";
import binance from "./binance.png";
import card from "./card.png";
import coinbase from "./coinbase.png";
import dropbox from "./dropbox.png";
import google from "./google.svg";
import apple from "./apple.svg";
import arrowUp from "./arrow-up.svg";
import facebook from "./facebook.svg";
import instagram from "./instagram.svg";
import linkedin from "./linkedin.svg";


export {
  airbnb,
  bill,
  binance,
  card,
  coinbase,
  dropbox,
  google,
  apple,
  arrowUp,
  facebook,
  instagram,
  linkedin,
};
