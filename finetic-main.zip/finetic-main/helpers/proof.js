import React from 'react'

const proof = () => {
  return (
    <div>proof</div>
  )
}

export default proof